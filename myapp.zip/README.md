# agenda-app
Resource scheduling platform

This platform is designed for companies to manage their resources, by allowing client self-managed session scheduling, and company members to organize and optimize their resource exploitation.

Users permissions and workflows:
- Admin
- Branch
- Resource
- Client
